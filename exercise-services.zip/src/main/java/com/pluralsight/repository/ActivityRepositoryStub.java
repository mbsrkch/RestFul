package com.pluralsight.repository;

import java.util.ArrayList;
import java.util.List;

import com.pluralsight.model.Activity;
import com.pluralsight.model.User;

public class ActivityRepositoryStub implements ActivityRepository {

	public List<Activity> findAllActivities(){
		List<Activity> activities = new ArrayList<Activity>();
		
		Activity activity1 = new Activity();
		
		activity1.setDescrption("Swimming");
		activity1.setDuration("55");
		
		activities.add(activity1);
		
		Activity activity2 = new Activity();
		
		activity2.setDescrption("Cycling");
		activity2.setDuration("120");
		
		activities.add(activity2);
		
		return activities;
		
	}
	@Override
	public Activity findlActivity(String activityId) {
		// TODO Auto-generated method stub
		
		
		Activity activity1 = new Activity();
		
		activity1.setId("1234");
		activity1.setDescrption("Swimming");
		activity1.setDuration("55");
		
		User user = new User();
		user.setId("5678");
		user.setName("chil");
		
		activity1.setUser(user);
		return activity1;
	}
	@Override
	public void create(Activity activity) {
		// should issue an insert statement to the db
		
	}
	
	
}
